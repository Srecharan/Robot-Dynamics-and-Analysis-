%% rbvel2twist(V_hat) is the inverse mapping of twist2rbvel. 

function V = rbvel2twist(V_hat)
    % Extract the 6-element twist vector V from a 4x4 rigid body velocity matrix in homogeneous coordinates V_hat
    V = [V_hat(1:3, 4); unskewSymmetricMatrix(V_hat(1:3, 1:3))];
end
function w = unskewSymmetricMatrix(W_hat)
    % Extract a 3-element vector w from a 3x3 skew-symmetric matrix W_hat
    w = [W_hat(3, 2); W_hat(1, 3); W_hat(2, 1)];
end
