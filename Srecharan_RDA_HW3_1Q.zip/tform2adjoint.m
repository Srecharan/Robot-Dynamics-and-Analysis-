% tform2adjoint.m
function Adg = tform2adjoint(g)
    % Extract the rotation matrix R and translation vector p from the homogeneous transformation matrix g
    R = g(1:3, 1:3);
    p = g(1:3, 4);  
    % Create the 6x6 adjoint transformation matrix Adg
    Adg = zeros(6, 6);    
    % Populate the upper-left 3x3 block with R
    Adg(1:3, 1:3) = R;  
    % Populate the lower-right 3x3 block with R
    Adg(4:6, 4:6) = R;    
    % Compute the 3x3 skew-symmetric matrix p_hat from the translation vector p
    p_hat = [0, -p(3), p(2); p(3), 0, -p(1); -p(2), p(1), 0];    
    % Populate the upper-right 3x3 block with p_hat
    Adg(1:3, 4:6) = p_hat;    
end

