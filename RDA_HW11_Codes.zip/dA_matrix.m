function[dA0,dA1,dA2,dA3,dA13] = dA_mat(x)
dA0 = [];
dA1 = [0,0];
dA2 = [0,0];
dA3 = [2*x(3),2*x(4)];
dA13 = [dA1;dA3];
end