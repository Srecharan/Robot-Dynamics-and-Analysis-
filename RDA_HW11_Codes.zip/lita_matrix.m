function[a0,a1,a2,a3] = lita_mat(x)
a0 = [];
a1 = x(2);
a2 = x(1)+x(2)+1;
a3 = (x(1)-2)^2+(x(2)-1)^2-2;
end
