%% Initialization

clear;clc;close all

% States
syms theta1 theta2 x_o y_o theta_o dtheta1 dtheta2 x_do y_do theta_do ddtheta1 ddtheta2 x_ddo y_ddo theta_ddo real

% Physics
syms m_l L I_l w m_o I_o g real

% Inputs
syms tau_1 tau_2 real

% Constraint forces
syms lambda_1 lambda_2
lambda = [lambda_1; lambda_2];

% Finger coordinates
theta = [theta1;theta2];
dtheta = [dtheta1;dtheta2];
ddtheta = [ddtheta1;ddtheta2];

% Body coordinates
x = [x_o; y_o; theta_o];
dx = [x_do; y_do; theta_do];
ddx = [x_ddo; y_ddo; theta_ddo];

% Local coordinates
q = [theta;x];
dq = [dtheta; dx];
ddq = [ddtheta; ddx];

%% Problem 1.1

% TODO: Compute inertia matrix in local coordinates M
M = sym(zeros(5, 5));
M1 = [m_l 0 0;
      0 m_l 0;
      0 0 I_l];
M2 = M1;
M_o =  [m_o 0 0;
        0 m_o 0;
        0 0 I_o];

Jbsl1 = [0 0;
          L/2 0
          1 0];
Jbsl2 = [L*sin(theta2) 0
          L*cos(theta2)+L/2 L/2
          1 1];
Jbp = [cos(theta_o) sin(theta_o) 0
         -sin(theta_o) cos(theta_o) 0
         0 0 1];

M_h = [Jbsl1'*M1*Jbsl1 + Jbsl2'*M2*Jbsl2,  zeros(length(dtheta),length(dx))
    zeros(length(dtheta),length(dx))',    M_o];
M = [eye(length(dtheta)), zeros(length(dtheta),length(dx))
    zeros(length(dx),length(dtheta)), Jbp']*M_h*[eye(length(dtheta)), zeros(length(dtheta),length(dx))
    zeros(length(dx),length(dtheta)), Jbp];

% TODO: Compute Coriolis matrix in local coordinates Cbar
Cbar  = sym(zeros(5, 5));
for i = 1:5
    for j = 1:5
        for k = 1:5
            Cbar(i,j) = Cbar(i,j) + 0.5*(diff(M(i,j),q(k)) + diff(M(i,k),q(j)) - diff(M(j,k),q(i)))*dq(k);
        end
    end
end


% TODO: Compute nonlinear terms Nbar
Nbar = sym(zeros(5, 1));
V_pot = (m_l*g*(w/2+L/2*sin(theta1))) + (m_l*g*(w/2 + L*sin(theta1)) + (L/2*sin(theta1+theta2))) + m_o*g*y_o;
Nbar = jacobian(V_pot, q)';

% TODO: Compute applied force Y
Y = sym(zeros(5, 1));
Y = [tau_1; tau_2; 0; 0; 0];

% TODO: Compute A matrix
A = sym(zeros(2, 5));
Bc1 = eye(6,2);

goc = [1 0 0 0;
       0 1 0 -w/2;
       0 0 1 0;
       0 0 0 1];
G1 = [tform2adjoint(inv(goc))'*Bc1];
G1 = G1([1,2,6],:);
Jbp = [cos(theta_o) sin(theta_o) 0
       -sin(theta_o) cos(theta_o) 0
       0 0 1];
GbarT = G1'*Jbp;

gsc = [cos(theta_o) -sin(theta_o) 0 L*cos(theta1) + L*cos(theta1+theta2) 
        sin(theta_o) cos(theta_o) 0 L*sin(theta1) + L*sin(theta1+theta2)      
        0 0 1 0
        0 0 0 1];
Jsf1 = [0 sin(theta1)*L
         0 -cos(theta1)*L
         0 0
         0 0
         0 0
         1 1];
J_h = Bc1'*inv(tform2adjoint(gsc))*Jsf1;

A = [-J_h GbarT];

% TODO: Compute dA matrix
dA = sym(zeros(2, 5));
for i = 1:5
    dA = dA + diff(A, q(i))*dq(i);  
end
C = size(A,1);

% TODO: Compute equations of motion
EOM = sym(zeros(5, 1));
EOM = M*ddq + Cbar*dq + Nbar + A'*lambda - Y;

%% Problem 1.2

% TODO: Compute acceleration ddq_massive
ddq_massive = sym(zeros(5, 1));
variables = [tau_1; tau_2; L; m_l; I_l; w; m_o; I_o; g; q; dtheta1; dtheta2; x_do; y_do; theta_do];
value = [200; 0; 0.1; 1; 8.33e-4; 0.2; 24; 0.16; 9.81; pi/2; -pi/2; 0.1; 0.2; 0; 0; 0; 0; 0; 0];
bmi = inv([M A';A zeros(C,C)]);
Lambda = bmi(length(q)+1:end, length(q)+1:end);
Md = bmi(1:length(q), 1:length(q));
Ad = bmi(length(q)+1:end, 1:length(q));
ddq_massive = Md*(Y - Cbar*dq - Nbar) - Ad'*dA*dq;

% TODO: Compute numerical acceleration ddq_eval_massive
ddq_eval_massive = zeros(5, 1);
ddq_eval_massive = subs(ddq_massive, variables, value);

%% Problem 1.3

% TODO: Compute massless EOM EOM_massless
EOM_massless = sym(zeros(5, 1));
EOM_massless = subs(EOM, [m_l, I_l], [0,0]);

%% Problem 1.4

% TODO: Compute numerical acceleration ddq_eval_massless
ddq_eval_massless = zeros(5, 1);
variables = [tau_1; tau_2; L; m_l; I_l; w; m_o; I_o; g; q; dtheta1; dtheta2; x_do; y_do; theta_do];
value = [200; 0; 0.1; 0; 0; 0.2; 24; 0.16; 9.81; pi/2; -pi/2; 0.1; 0.3; 0; 0; 0; 0; 0; 0];
ddq_eval_massless = subs(ddq_massive, variables, value);

% TODO: Compute error percentage error_from_massless
error_from_massless = zeros(5, 1);
error_from_massless = abs(1 - ddq_eval_massless./ddq_eval_massive)*100;

%% Problem 1.5

% TODO: Compute the updated A matrix A_frictionless
A_frictionless = sym(zeros(1, 5));
lambda_frictionless = lambda_2;
C_frictionless = length(lambda_frictionless); 
A_frictionless = A(2, :);

% TODO: Compute the updated dA matrix dA_frictionless
dA_frictionless = sym(zeros(1, 5));
for i = 1:5
    dA_frictionless = dA_frictionless + diff(A_frictionless, q(i))*dq(i); 
end

% TODO: Compute the updated EOM EOM_frictionless
EOM_frictionless = sym(zeros(5, 1));
EOM_frictionless = M*ddq + Cbar*dq + Nbar + A_frictionless'*lambda_frictionless - Y;

%% Problem 1.6

% TODO: Compute massless and frictionless EOM EOM_massless_frictionless
EOM_massless_frictionless = sym(zeros(5, 1));
EOM_massless_frictionless = subs(EOM_frictionless, [m_l, I_l], [0,0]);

% TODO: Compute the rank of the block matrix
rank_bm = 0;
rank_bm = rank(subs([M A_frictionless';A_frictionless zeros(C_frictionless,C_frictionless)], [m_l, I_l], [0,0]));
