% compare_twist.m
function compare_twist()
    % Generate a random 4x4 homogeneous transformation matrix g
    g = random_homogeneous_matrix();
    % Compute the spatial velocity Vs_hat and body velocity Vb_hat
    Vs_hat = compute_spatial_velocity(g);
    Vb_hat = compute_body_velocity(g);
    % Convert the spatial velocity Vs_hat to a spatial twist Vs
    Vs = rbvel2twist(Vs_hat);
    % Convert the body velocity Vb_hat to a body twist Vb
    Vb = rbvel2twist(Vb_hat);
    % Display the generated transformation matrix g
    disp('Generated Transformation Matrix g:');
    disp(g);
    % Display the spatial and body twists
    disp('Spatial Twist Vs:');
    disp(Vs);
    disp('Body Twist Vb:');
    disp(Vb);
    % Check if the spatial twist and body twist are approximately equal (within a tolerance)
    tolerance = 1e-6;
    is_equal = all(abs(Vs - Vb) < tolerance);
    if is_equal
        disp('Test is passed as Spatial Twist and Body Twist are equal.');
    else
        disp('Test is failed as Spatial Twist and Body Twist are not equal.');
    end
end
function g = random_homogeneous_matrix()
    % Generate a random 4x4 homogeneous transformation matrix
    R = random_rotation_matrix();
    p = rand(3, 1);
    g = eye(4);
    g(1:3, 1:3) = R;
    g(1:3, 4) = p;
end
function R = random_rotation_matrix()
    % Generate a random 3x3 rotation matrix
    theta = rand() * 2 * pi;
    v = rand(3, 1);
    v = v / norm(v);
    K = [0, -v(3), v(2);
         v(3), 0, -v(1);
        -v(2), v(1), 0];
    R = eye(3) + sin(theta) * K + (1 - cos(theta)) * K^2;
end
function Vs_hat = compute_spatial_velocity(g)
    % Compute the spatial velocity Vs_hat from the transformation matrix g
    Vs_hat = eye(4);
    Vs_hat(1:3, 4) = g(1:3, 4);
end
function Vb_hat = compute_body_velocity(g)
    % Compute the body velocity Vb_hat from the transformation matrix g
    Vb_hat = g;
    Vb_hat(1:3, 4) = [0; 0; 0];
end


