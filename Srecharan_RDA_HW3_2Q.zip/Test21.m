function test_angvel_skew()
    w = rand(3, 1);  % Generate a random angular velocity vector
    W_hat = angvel2skew(w);  % Convert to skew-symmetric matrix
    w_prime = skew2angvel(W_hat);  % Convert back to angular velocity vector

    if all(abs(w - w_prime) < 1e-6)
        disp('Test is passed as angvel2skew and skew2angvel are inverse of each other.');
    else
        disp('Test is failed as angvel2skew and skew2angvel are not inverse of each other.');
    end
end

function W_hat = angvel2skew(w)
    W_hat = [0, -w(3), w(2); w(3), 0, -w(1); -w(2), w(1), 0];
end

function w = skew2angvel(W_hat)
    w = [W_hat(3,2); W_hat(1,3); W_hat(2,1)];
end