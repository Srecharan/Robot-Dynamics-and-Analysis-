% Generate a random twist vector V
V = rand(6, 1);
% Call twist2rbvel to convert V to a 4x4 rigid body velocity matrix in homogeneous coordinates V_hat
V_hat = twist2rbvel(V);

% Call rbvel2twist to convert the rigid body velocity matrix V_hat back to a twist vector V_prime
V_prime = rbvel2twist(V_hat);
% Check if V and V_prime are approximately equal (within a tolerance)
tolerance = 1e-6;
is_equal = all(abs(V - V_prime) < tolerance);
if is_equal
    disp('Test is passed as angvel2skew and skew2angvel are inverse of each other.');
else
    disp('Test is failed as twist2rbvel and rbvel2twist are not inverse of each other.');
end

function V_hat = twist2rbvel(V)
    % Create a 4x4 rigid body velocity matrix in homogeneous coordinates from a 6-element twist vector V
    V_hat = [skewSymmetricMatrix(V(1:3)), V(4:6);
             zeros(1, 4)];
end
function W_hat = skewSymmetricMatrix(w)
    % Create a 3x3 skew-symmetric matrix from a 3-element vector w
    W_hat = [0, -w(3), w(2); w(3), 0, -w(1); -w(2), w(1), 0];
end
function V = rbvel2twist(V_hat)
    % Extract the 6-element twist vector V from a 4x4 rigid body velocity matrix in homogeneous coordinates V_hat
    V = [V_hat(1:3, 4); unskewSymmetricMatrix(V_hat(1:3, 1:3))];
end
function w = unskewSymmetricMatrix(W_hat)
    % Extract a 3-element vector w from a 3x3 skew-symmetric matrix W_hat
    w = [W_hat(3, 2); W_hat(1, 3); W_hat(2, 1)];
end
