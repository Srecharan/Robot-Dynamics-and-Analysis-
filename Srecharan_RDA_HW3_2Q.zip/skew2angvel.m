function w = skew2angvel(W_hat)
    % Extract the angular velocity vector w from a 3x3 skew-symmetric matrix W_hat
    w = [W_hat(3,2); W_hat(1,3); W_hat(2,1)];
end
