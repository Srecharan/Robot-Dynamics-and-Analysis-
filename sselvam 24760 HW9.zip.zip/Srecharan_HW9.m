%% Initialization

clear all; close all; clc;

% States
syms x y theta real

% Physics
syms w h m real

% Local coordinates
q = [x; y; theta;];

% Constraints
a = [
    y - h*cos(theta) - w*sin(theta);
    y - h*cos(theta) + w*sin(theta);
];

%% Problem 1.1

% TODO: Compute A matrix
A = sym(zeros(2, 3));
A = [jacobian(a,q)];
Iz1 = (1/3)*(m*(w^2+h^2));

% TODO: Compute M matrix
M = sym(zeros(3, 3));
M = [m 0 0;0 m 0;0 0 Iz1]

%% Problem 1.2

% TODO: Compute dq_plus for the wide block
dq_plus_wide = sym(zeros(3, 1));
variable1 = [m w h x y theta];
value1 = [1 2 1 2 1 0];
M = subs(M,variable1,value1)
A = subs(A,variable1,value1)
dq_minus_wide = [1;-2;-1];
CM = simplify([M A';A zeros(2,2)]);
CG = [M*dq_minus_wide;zeros(2,1)];
X1 = simplify(inv(CM)*CG);
dq_plus_wide = simplify([X1(1);X1(2);X1(3)])

% TODO: Compute P_hat for the wide block
P_hat_wide = sym(zeros(2, 1));
P_hat_wide = simplify([X1(4);X1(5)])

% TODO: Verify post-impact constraint velocities (A*dq_plus >= 0) for the
% wide block
A_dq_plus_wide = sym(zeros(2,1));
A_dq_plus_wide = A*dq_plus_wide

% TODO: Verify impulses are valid (P_hat <= 0) for the wide block (No
% calculations need to be done for this part as P_hat_wide has already
% been calculated)

fprintf('The observed value of P_hat_wide is %.2f, which is negative and hence <= 0.\n', P_hat_wide);

%% Problem 1.3

% TODO: Compute dq_plus for the narrow block
dq_plus_narrow = sym(zeros(3, 1));
variable2 = [m w h x y theta];
value2 = [1 1 2 1 2 0];
q1 = [x;y;theta];
dq_minus_narrow = [2;-1;-1]
A1 = [jacobian(a,q1)];
q1 = subs(q1,variable2,value2);
A1 = subs(A1,variable2,value2)
Iz1 = subs(Iz1,variable2,value2)
M1 = [m 0 0;0 m 0;0 0 Iz1];
M1 = subs(M1,variable2,value2)
CM1 = simplify([M1 A1';A1 zeros(2,2)]);
CG1 = [M1*dq_minus_narrow;zeros(2,1)];
X2 = inv(CM1)*CG1;
dq_plus_narrow = [X2(1);X2(2);X2(3)]

% TODO: Compute P_hat for the narrow block
P_hat_narrow = sym(zeros(2, 1));
P_hat_narrow = [X2(4);X2(5)]

% TODO: Verify post-impact constraint velocities (A*dq_plus >= 0) are
% either valid or invalid for the narrow block
A_dq_plus_narrow = sym(zeros(2,1));
A_dq_plus_narrow = A1*dq_plus_narrow

fprintf('The post-impact constraint velocities are valid as all elements are greater than or equal to 0.\n');

% TODO: Verify impulses (P_hat <= 0) are either valid or invalid for the
% narrow block (No calculations need to be done for this part as
% P_hat_narrow has already been calculated)

fprintf('P_hat_narrow is invalid because the top value, %.2f, is greater than 0.\n', P_hat_narrow(1));

%% Problem 1.4

% TODO: Compute dq_plus for the narrow block with the correct contact mode
dq_plus_correct = sym(zeros(3, 1));
a2 = [y-h*cos(theta)+w*sin(theta);];
q2 = [x;y;theta];
dq_minus_narrow = [2;-1;-1]
A2 = [jacobian(a2,q2)];
q2 = subs(q2,variable2,value2);
A2 = subs(A2,variable2,value2);
Iz2 = subs(Iz1,variable2,value2);
M2 = [m 0 0;0 m 0;0 0 Iz2];
M2 = subs(M2,variable2,value2);
CM2 = simplify([M2 A2';A2 zeros(1,1)]);
CG2 = simplify([M2*dq_minus_narrow;zeros(1,1)]);
X3 = inv(CM2)*CG2;
dq_plus_correct = [X3(1);X3(2);X3(3)]

% TODO: Compute P_hat for the narrow block with the correct contact mode
P_hat_correct = sym(zeros(1, 1));
P_hat_correct = [X3(4)]

% TODO: Verify post-impact constraint velocities (A*dq_plus >= 0) are
% valid for the narrow block with the correct contact mode
A_dq_plus_correct = sym(zeros(2,1));
A_dq_plus_correct = A2*dq_plus_correct

% TODO: Verify impulses (P_hat <= 0) are valid for the narrow block with
% the correct contact mode (No calculations need to be done for this part
% as P_hat_correct has already been calculated)

fprintf('P_hat_correct is valid because its value, %.2f, is less than or equal to 0.\n', P_hat_correct);
